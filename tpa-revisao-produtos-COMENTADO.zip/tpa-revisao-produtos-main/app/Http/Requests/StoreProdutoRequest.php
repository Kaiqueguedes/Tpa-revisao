<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

// TROCAR: nome da classe (StoreProdutoRequest -> Store + nova entidade + Request)
class StoreProdutoRequest extends FormRequest
{
    // NÃO MUDA: precisa devolver true, senão toda requisição vira 403
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        // ADAPTAR: uma linha por campo do formulário, com as regras da tabela de contratos do README.
        // TROCAR: os nomes das chaves (nome, categoria...) -> nomes dos campos da nova entidade
        return [
            'nome' => 'required|string|max:255',
            // ADAPTAR: lista de valores permitidos (in:...) com os valores exatos do contrato
            'categoria' => 'required|in:Eletrônicos,Vestuário,Casa,Alimentos',
            // ADAPTAR: limites do contrato (between:0,36 = inteiro de 0 a 36)
            'garantia_meses' => 'required|integer|between:0,36',
            // ADAPTAR: gt:0 = maior que zero (min:0 seria "maior ou igual")
            'preco' => 'required|numeric|gt:0',
            'estoque' => 'required|integer|min:0',
        ];
    }
}
