<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

// NÃO MUDA: o login/logout é igual para qualquer entidade. Só confira os nomes de rota abaixo.
class LoginController extends Controller
{
    public function create()
    {
        return view('auth.login');
    }

    public function attempt(Request $request)
    {
        // ADAPTAR: só os campos do formulário de login (aqui: email e password)
        $credenciais = $request->only('email', 'password');

        if (Auth::attempt($credenciais)) {
            $request->session()->regenerate();

            // TROCAR: 'produtos.index' -> rota da listagem pública da nova entidade
            return redirect()->intended(route('produtos.index'));
        }

        // ADAPTAR: a chave 'email' precisa ser o campo onde a view mostra o erro (@error('email'))
        return back()
            ->withErrors(['email' => 'E-mail ou senha inválidos.'])
            ->onlyInput('email');
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        // TROCAR: 'home' -> rota para onde o logout deve levar (se o contrato pedir outra)
        return redirect()->route('home');
    }
}
