<?php

namespace App\Http\Controllers;

// TROCAR: Produto -> nova entidade (model)
use App\Models\Produto;
use Illuminate\Http\Request;
// TROCAR: StoreProdutoRequest -> Store + nova entidade + Request
use App\Http\Requests\StoreProdutoRequest;
use Illuminate\Support\Facades\Auth;

// TROCAR: nome do controller (ProdutoController -> NovaEntidadeController)
class ProdutoController extends Controller
{
    public function index()
    {
        // TROCAR: Produto -> nova entidade; $produtos -> variável que a view espera
        // TROCAR: 'vendedor' -> nome da relação criada na model (a que o contrato manda carregar com with)
        $produtos = Produto::with('vendedor')->get();

        // TROCAR: 'produtos.index' -> nome da view; 'produtos' em compact -> mesmo nome da variável acima
        return view('produtos.index', compact('produtos'));
    }

    public function create()
    {
        // TROCAR: 'produtos.create' -> nome da view do formulário
        return view('produtos.create');
    }

    // TROCAR: StoreProdutoRequest -> o FormRequest da nova entidade
    public function store(StoreProdutoRequest $request)
    {
        // TROCAR: Produto -> nova entidade
        // TROCAR: 'vendedor_id' -> coluna do dono no contrato (valor SEMPRE vem de Auth::id(), nunca do formulário)
        Produto::create($request->validated() + [
            'vendedor_id' => Auth::id(),
        ]);

        // TROCAR: 'produtos.index' -> nome da rota da listagem
        return redirect()->route('produtos.index');
    }
}
