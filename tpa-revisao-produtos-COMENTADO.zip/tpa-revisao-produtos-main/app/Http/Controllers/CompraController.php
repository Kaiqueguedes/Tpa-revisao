<?php

namespace App\Http\Controllers;

// TROCAR: Venda -> model da compra no contrato
use App\Models\Venda;
use Illuminate\Support\Facades\Auth;
// TROCAR: Produto -> nova entidade
use App\Models\Produto;
use Illuminate\Http\Request;

// TROCAR: nome do controller, se o contrato mudar (CompraController)
class CompraController extends Controller
{
    public function index()
    {
        // TROCAR: Venda -> model da compra; 'cliente_id' -> coluna do comprador no contrato
        // TROCAR: 'produtos' no with() -> nome da relação N:M da model (a mesma que a view usa)
        // ADAPTAR: o where() garante que cada usuário só veja as PRÓPRIAS compras (não remova)
        $vendas = Venda::where('cliente_id', Auth::id())
            ->with('produtos')
            ->latest()
            ->get();

        // TROCAR: 'compras.index' -> view; 'vendas' em compact -> variável que a view espera
        return view('compras.index', compact('vendas'));
    }

    public function create()
    {
        // TROCAR: Produto -> nova entidade; $produtos -> variável que a view espera
        $produtos = Produto::orderBy('nome')->get();

        // TROCAR: 'compras.create' -> nome da view
        return view('compras.create', compact('produtos'));
    }

    public function store(Request $request)
    {
        // ADAPTAR: 'itens' é o nome do campo enviado pelo formulário (veja o name="itens[...]" na view)
        // O filter ignora itens com quantidade 0
        $itens = collect($request->input('itens', []))
            ->filter(fn ($quantidade) => (int) $quantidade > 0);

        // TROCAR: Venda -> model da compra; 'cliente_id' -> coluna do comprador
        $venda = Venda::create(['cliente_id' => Auth::id()]);

        foreach ($itens as $produtoId => $quantidade) {
            // TROCAR: Produto -> nova entidade
            $produto = Produto::findOrFail($produtoId);

            // TROCAR: produtos() -> nome da relação N:M da model
            // ADAPTAR: as chaves do array são as colunas extras da pivô; 'preco_unitario' guarda o valor ATUAL do item
            $venda->produtos()->attach($produto->id, [
                'quantidade' => (int) $quantidade,
                'preco_unitario' => $produto->preco,
            ]);
        }

        // TROCAR: 'compras.index' -> rota de destino; 'sucesso' é a chave que o layout exibe (não muda)
        return redirect()->route('compras.index')->with('sucesso', 'Compra realizada!');
    }
}
