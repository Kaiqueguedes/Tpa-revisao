<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

// TROCAR: nome da classe (VendedorMiddleware -> perfil do contrato + Middleware)
class VendedorMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        // TROCAR: 'vendedor' -> o perfil permitido no contrato (valor guardado na coluna do usuário)
        // ADAPTAR: ->tipo é a coluna do perfil na tabela users; confira o nome dela na migration de users
        if (Auth::user()->tipo !== 'vendedor') {
            // NÃO MUDA: abort(403) mostra a página de acesso negado
            abort(403);
        }

        return $next($request);
    }
}
