<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// TROCAR: nome da classe (Produto -> nova entidade, no singular, com inicial maiúscula)
class Produto extends Model
{
    // ADAPTAR: liste TODAS as colunas da migration que serão preenchidas em massa (inclusive a chave do dono)
    protected $fillable = [
        'nome',
        'categoria',
        'garantia_meses',
        'preco',
        'estoque',
        'vendedor_id',
    ];

    // TROCAR: nome da relação (vendedor -> o nome que o contrato/view pedir, ex.: autor, dono)
    public function vendedor()
    {
        // TROCAR: 'vendedor_id' -> nome da coluna da chave estrangeira do dono (User::class continua igual)
        return $this->belongsTo(User::class, 'vendedor_id');
    }
}
