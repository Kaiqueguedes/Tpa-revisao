<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// TROCAR: nome da classe (Venda -> a entidade da compra no contrato, ex.: Pedido, Emprestimo)
class Venda extends Model
{
    // TROCAR: 'cliente_id' -> coluna do comprador, como está no contrato
    protected $fillable = ['cliente_id'];

    // TROCAR: nome da relação (produtos -> plural da nova entidade; a view usa esse nome)
    public function produtos()
    {
        // TROCAR: Produto::class -> nova entidade; 'produto_venda' -> nome da tabela pivô do contrato
        return $this->belongsToMany(Produto::class, 'produto_venda')
            // ADAPTAR: colunas extras da pivô, iguais às da migration da pivô
            ->withPivot('quantidade', 'preco_unitario')
            ->withTimestamps();
    }
}
