<?php

// TROCAR: os controllers, se o contrato mudar os nomes
use App\Http\Controllers\CompraController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ProdutoController;
use Illuminate\Support\Facades\Route;

// Páginas de ilustração (prontas)
Route::view('/', 'home')->name('home');
Route::view('/sobre', 'sobre')->name('sobre');

// Autenticação
Route::get('/login', [LoginController::class, 'create'])->name('login');
Route::post('/login', [LoginController::class, 'attempt'])->name('login.attempt');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Produtos
// ADAPTAR: a listagem fica FORA dos grupos de middleware, pois é pública
// TROCAR: /produtos, ProdutoController e 'produtos.index' -> URL, controller e nome de rota do contrato
Route::get('/produtos', [ProdutoController::class, 'index'])->name('produtos.index');

// Rotas que exigem login
// ADAPTAR: 'auth' = qualquer usuário logado (já vem pronto no Laravel)
Route::middleware('auth')->group(function () {
    // ADAPTAR: 'vendedor' = apelido registrado em bootstrap/app.php; vale só para o cadastro
    Route::middleware('vendedor')->group(function () {
        // TROCAR: URLs, controller e nomes das rotas conforme o contrato
        Route::get('/produtos/create', [ProdutoController::class, 'create'])->name('produtos.create');
        Route::post('/produtos', [ProdutoController::class, 'store'])->name('produtos.store');
    });

    // Compras
    // ADAPTAR: compras ficam só com 'auth' (cliente também precisa acessar); não coloque 'vendedor' aqui
    // TROCAR: URLs, controller e nomes das rotas conforme o contrato
    Route::get('/compras', [CompraController::class, 'index'])->name('compras.index');
    Route::get('/compras/create', [CompraController::class, 'create'])->name('compras.create');
    Route::post('/compras', [CompraController::class, 'store'])->name('compras.store');
});
