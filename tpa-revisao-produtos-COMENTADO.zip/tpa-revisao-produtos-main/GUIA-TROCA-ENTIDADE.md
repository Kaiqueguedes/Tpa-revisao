# Guia: como trocar a entidade (Produto → outra) na prova

Este arquivo é só para estudo. O `README.md` original do professor continua intacto.

No código, procure por **`// TROCAR:`** (basta renomear) e **`// ADAPTAR:`** (precisa pensar:
colunas, regras, relações). Conteúdo marcado com **`// NÃO MUDA:`** é igual para qualquer entidade.

---

## 1. Passo zero: leia o contrato da prova

Antes de escrever qualquer coisa, abra o README da prova e anote estas 8 respostas.
Tudo no código vem delas.

| # | Pergunta | Nesta atividade | Na prova |
|---|---|---|---|
| 1 | Nome da model e da tabela | `Produto` / `produtos` | |
| 2 | Colunas, tipos e validações | nome, categoria, garantia_meses, preco, estoque | |
| 3 | Coluna do dono e nome da relação | `vendedor_id` / `vendedor()` | |
| 4 | Perfil e apelido do middleware | `vendedor` | |
| 5 | Model e tabela da compra | `Venda` / `vendas` (`cliente_id`) | |
| 6 | Relação N:M e tabela pivô | `produtos()` / `produto_venda` | |
| 7 | Colunas extras da pivô | `quantidade`, `preco_unitario` | |
| 8 | Nomes das rotas e das variáveis das views | `produtos.index`, `$produtos`, `$vendas` | |

> As **views já vêm prontas**. Não mexa nelas. Leia-as só para descobrir os nomes
> que o seu código precisa respeitar (veja a seção 4).

---

## 2. Mapa dos arquivos (o que mexer em cada requisito)

| Req. | Arquivo | O que trocar / adaptar |
|---|---|---|
| R1 | `database/migrations/..._create_produtos_table.php` | **TROCAR** nome da tabela (no `up` e no `down`). **ADAPTAR** uma linha por coluna. **TROCAR** a chave do dono. |
| R1 | `app/Models/Produto.php` | **TROCAR** nome da classe e da relação. **ADAPTAR** o `$fillable` (todas as colunas, inclusive a do dono). |
| R1 | `app/Http/Controllers/ProdutoController.php` (`index`) | **TROCAR** model, variável, nome da relação no `with()` e nome da view. |
| R2 | `app/Http/Controllers/LoginController.php` | Quase nada. Só o nome da rota do redirect. |
| R3 | `routes/web.php` | Colocar as rotas certas dentro de `Route::middleware('auth')->group(...)`. A listagem fica fora. |
| R4 | `app/Http/Middleware/VendedorMiddleware.php` | **TROCAR** nome da classe e o valor do perfil (`'vendedor'`). |
| R4 | `bootstrap/app.php` | **TROCAR** o apelido (`'vendedor'`) e a classe no `alias`. |
| R4 | `routes/web.php` | **TROCAR** o apelido em `Route::middleware('...')` nas rotas de cadastro. |
| R5 | `app/Http/Requests/StoreProdutoRequest.php` | **TROCAR** nome da classe. **ADAPTAR** `rules()` com a tabela de contratos. |
| R5/R6 | `ProdutoController.php` (`store`) | **TROCAR** request, model e coluna do dono. O dono vem de `Auth::id()`, nunca do formulário. |
| R7 | `database/migrations/..._create_vendas_table.php` | **TROCAR** tabela e coluna do comprador. |
| R7 | `database/migrations/..._create_produto_venda_table.php` | **TROCAR** nome da pivô e as chaves. **ADAPTAR** colunas extras. |
| R7 | `app/Models/Venda.php` | **TROCAR** nome da classe e da relação N:M. **ADAPTAR** `withPivot(...)`. |
| R7 | `CompraController.php` (`store`) | **TROCAR** models e relação. **ADAPTAR** o que vai na pivô no `attach`. |
| R8 | `CompraController.php` (`index`) | **TROCAR** model e relação no `with()`. **Mantenha** o `where` do usuário logado. |

---

## 3. O que NÃO muda (não perca tempo)

- Todo o `LoginController` (`Auth::attempt`, `regenerate`, `invalidate`).
- `authorize()` retornando `true` no FormRequest.
- `abort(403)` no middleware.
- A estrutura dos grupos de rotas (`auth` por fora, perfil por dentro).
- A chave `'sucesso'` no `with(...)` (é a que o layout exibe).
- O `Auth::id()` para preencher dono e comprador.
- `with()` para evitar consulta repetida (N+1).

---

## 4. Onde conferir os nomes que as views esperam

Se o seu código usar um nome diferente do que a view usa, a tela quebra.

| View | O que ela espera |
|---|---|
| `produtos/index.blade.php` | variável `$produtos`; cada item com `->vendedor->name` |
| `produtos/create.blade.php` | campos com `name="nome"`, `categoria`, etc. (iguais às colunas) |
| `compras/create.blade.php` | variável `$produtos`; envia `itens[id] = quantidade` |
| `compras/index.blade.php` | variável `$vendas`; `$venda->produtos`; `->pivot->quantidade` e `->pivot->preco_unitario` |
| `auth/login.blade.php` | campos `email` e `password`; erro mostrado em `email` |
| `layouts/app.blade.php` | mensagem em `session('sucesso')`; usa `Auth::user()->name` e `->tipo` |
| `errors/403.blade.php` | texto fixo "exclusiva para vendedores" (só visual) |

---

## 5. Comandos, na ordem em que você roda

Rode **sempre dentro da pasta que contém o `composer.json`** (cuidado com pasta dentro de pasta ao descompactar).

### 5.1. Preparar o projeto (uma vez)

```powershell
composer install
Copy-Item .env.example .env
php artisan key:generate
New-Item database/database.sqlite -ItemType File
```

No Linux/Mac, troque a 2ª e a 4ª linhas por `cp .env.example .env` e `touch database/database.sqlite`.

### 5.2. Criar os arquivos novos

Rode **um comando de cada vez**, nesta ordem (a ordem importa por causa das migrations):

```powershell
php artisan make:model NovaEntidade -m
php artisan make:model NovaVenda -m
php artisan make:migration create_nova_entidade_nova_venda_table
php artisan make:middleware NomeDoPerfilMiddleware
php artisan make:request StoreNovaEntidadeRequest
```

| Comando | Para quê |
|---|---|
| `make:model X -m` | cria a model **e** a migration da tabela (o `-m` é a migration) |
| `make:model Venda -m` | só se o contrato pedir uma model nova para a compra |
| `make:migration create_..._table` | cria a migration da **pivô** (use o nome de tabela do contrato) |
| `make:middleware` | cria o middleware de perfil (R4) |
| `make:request` | cria o FormRequest de validação (R5) |

> **Regra da ordem das migrations:** a pivô precisa ser criada **depois** da tabela da entidade e da tabela
> da compra, porque o nome do arquivo começa com data e hora e o Laravel roda na ordem do nome.
> Se criar dois comandos no mesmo segundo, a ordem pode sair errada. Se der erro de tabela inexistente
> na pivô, confira se o arquivo dela é o último da pasta `database/migrations`.

### 5.3. Depois de escrever o código

```powershell
php artisan migrate:fresh --seed
php artisan serve
```

- `migrate:fresh --seed` **apaga o banco inteiro**, recria as tabelas e roda os seeders.
  Rode toda vez que mexer em migration ou seeder. As compras de teste somem, e isso é normal.
- O aviso "Produtos não semeados" só some quando a migration e a model estiverem corretas.
- `serve` sobe o site em http://localhost:8000. Ele ocupa o terminal; para outros comandos, abra outro terminal.

### 5.4. Quando algo der errado

```powershell
php -l app/Http/Controllers/ProdutoController.php
php artisan route:list
php artisan optimize:clear
```

| Comando | Quando usar |
|---|---|
| `php -l arquivo.php` | confere **erro de sintaxe** de um arquivo (chave sobrando, `;` faltando) |
| `php artisan route:list` | mostra as rotas e quais middlewares cada uma tem |
| `php artisan optimize:clear` | limpa os caches (use se uma mudança "não pegou") |

**Terminal diz que `php` não é reconhecido?** Num terminal novo, recarregue o PATH:

```powershell
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
```

---

## 6. Checklist de teste (na ordem do README)

1. `/produtos` sem login mostra a tabela, com o dono em cada linha. (R1)
2. Senha errada volta ao login com erro; senha certa mostra nome e tipo no topo; **Sair** volta o botão **Entrar**. (R2)
3. Deslogado, os três links protegidos levam ao login; a listagem abre normal. (R3)
4. Cliente em **Cadastrar** vê 403; vendedor vê o formulário. (R4)
5. Formulário vazio mostra um erro por campo; valor fora do limite e valor zero dão erro no campo certo; dados válidos voltam à listagem. (R5)
6. O dono de cada item é o usuário que cadastrou. (R6)
7. Compra com quantidades diferentes de zero leva a **Minhas compras** com "Compra realizada!". (R7)
8. A compra mostra só os itens escolhidos; outro usuário **não** vê as compras alheias. (R8)

---

## 7. Erros que já apareceram (e a causa)

| Sintoma | Causa provável |
|---|---|
| `ParseError ... unexpected token "public"` | método ou propriedade **fora** das chaves da classe, ou `}` sobrando |
| Formulário sempre dá 403 | `authorize()` do FormRequest retornando `false` |
| Produto salva vazio ou dá erro de coluna | falta o `$fillable` na model, ou falta alguma coluna nele |
| Erro `NOT NULL ... vendedor_id` | esqueceu de preencher o dono com `Auth::id()` no `store` |
| Erro ao carregar a migration da pivô | arquivo com sintaxe errada (confira o `};` final) ou ordem errada das migrations |
| `Class "...Produto" not found` | faltou o `use App\Models\Produto;` no topo do controller |
| Login falha com a senha certa | e-mail com espaço ou `.com` em vez de `.test`; ou banco recriado sem `--seed` |
| Link "Cadastrar" nunca dá 403 | middleware `vendedor` não está nas rotas de cadastro (confira com `route:list`) |
| Compras de todos aparecem para todos | faltou o `where('cliente_id', Auth::id())` no `index` |

---

## 8. Limites conhecidos deste projeto

- **O bônus (estoque) não está implementado**, porque a atividade foi entregue sem ele. Veja a seção 9.
- Se o cliente finalizar com **todas as quantidades em 0**, o código cria uma venda vazia. O README não
  exige tratar isso, mas dá para recusar com `if ($itens->isEmpty()) { return back()->withErrors(...); }`.

---

## 9. Bônus de estoque (referência, NÃO está no código do projeto)

Para quem quiser treinar. Este trecho **não foi testado neste projeto**. Ele substitui o `store`
do `CompraController` e faz duas coisas: recusa a compra se alguma quantidade passar do estoque e,
ao concluir, desconta o estoque.

```php
public function store(Request $request)
{
    $itens = collect($request->input('itens', []))
        ->filter(fn ($quantidade) => (int) $quantidade > 0);

    // 1) Antes de criar a venda, confira o estoque de cada item.
    foreach ($itens as $produtoId => $quantidade) {
        $produto = Produto::findOrFail($produtoId);

        if ((int) $quantidade > $produto->estoque) {
            return back()
                ->withErrors(['itens' => "Estoque insuficiente para {$produto->nome}."])
                ->withInput();
        }
    }

    // 2) Só chega aqui se todos os itens couberam no estoque.
    $venda = Venda::create(['cliente_id' => Auth::id()]);

    foreach ($itens as $produtoId => $quantidade) {
        $produto = Produto::findOrFail($produtoId);

        $venda->produtos()->attach($produto->id, [
            'quantidade' => (int) $quantidade,
            'preco_unitario' => $produto->preco,
        ]);

        // 3) Desconta do estoque.
        $produto->decrement('estoque', (int) $quantidade);
    }

    return redirect()->route('compras.index')->with('sucesso', 'Compra realizada!');
}
```

A checagem vem **antes** do `Venda::create` de propósito: assim, quando a compra é recusada, nenhuma
venda fica criada (é o que o teste do README verifica).
