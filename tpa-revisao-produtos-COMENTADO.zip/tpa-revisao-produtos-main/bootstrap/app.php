<?php

// TROCAR: VendedorMiddleware -> nome da classe do seu middleware
use App\Http\Middleware\VendedorMiddleware;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            // TROCAR: 'vendedor' -> apelido exigido no contrato (é o nome usado em ->middleware('...') nas rotas)
            // TROCAR: VendedorMiddleware::class -> classe do seu middleware
            'vendedor' => VendedorMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
