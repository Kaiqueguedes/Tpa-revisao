<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // TROCAR: 'produtos' -> nome da tabela do contrato (plural, minúsculo)
        Schema::create('produtos', function (Blueprint $table) {
            $table->id();
            // ADAPTAR: uma linha por coluna do contrato (string = texto, integer = inteiro, decimal(total, casas) = dinheiro)
            $table->string('nome');
            $table->string('categoria');
            $table->integer('garantia_meses');
            $table->decimal('preco', 8, 2);
            $table->integer('estoque');
            // TROCAR: 'vendedor_id' -> coluna do dono no contrato; 'users' fica igual (tabela dos usuários)
            $table->foreignId('vendedor_id')->constrained('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // TROCAR: 'produtos' -> mesmo nome da tabela acima
        Schema::dropIfExists('produtos');
    }
};
