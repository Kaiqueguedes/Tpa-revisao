<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // TROCAR: 'produto_venda' -> nome da tabela pivô do contrato (o mesmo usado no belongsToMany da model)
        Schema::create('produto_venda', function (Blueprint $table) {
            $table->id();
            // TROCAR: 'venda_id' / 'vendas' -> chave e tabela da compra
            $table->foreignId('venda_id')->constrained('vendas');
            // TROCAR: 'produto_id' / 'produtos' -> chave e tabela da nova entidade
            $table->foreignId('produto_id')->constrained('produtos');
            // ADAPTAR: colunas extras da pivô conforme o contrato (aqui: quantidade e preco_unitario)
            $table->integer('quantidade');
            $table->decimal('preco_unitario', 8, 2);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        // TROCAR: 'produto_venda' -> mesmo nome da pivô acima
        Schema::dropIfExists('produto_venda');
    }
};
