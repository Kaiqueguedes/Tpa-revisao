<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // TROCAR: 'vendas' -> nome da tabela da compra no contrato
        Schema::create('vendas', function (Blueprint $table) {
            $table->id();
            // TROCAR: 'cliente_id' -> coluna do comprador no contrato; 'users' fica igual
            $table->foreignId('cliente_id')->constrained('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // TROCAR: 'vendas' -> mesmo nome da tabela acima
        Schema::dropIfExists('vendas');
    }
};
